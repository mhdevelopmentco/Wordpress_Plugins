<?php

/**
 * View for Settings page section info
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

?>

<p class="wccf_section_info">
    <?php echo $info; ?>
</p>
